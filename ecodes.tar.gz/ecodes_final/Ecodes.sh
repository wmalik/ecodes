#!/bin/sh


cd scripts
./split.sh sailingfast.mp3
cd ..
java Ecodes $@ 2>&1 > /dev/null

cat target/object* > reconstructedFile.mp3
